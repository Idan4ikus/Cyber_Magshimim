#ifndef UTILS_H
#define UTILS_H

void reverse(int* nums, unsigned int size);
int* reverse10();

#endif // UTILS_H