#include "Utils.h"
#include <iostream>
using namespace std;

void reverse(int* nums, unsigned int size)
{
    unsigned int i = 0;
    unsigned int j = size - 1;

    while (i < j)
    {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;

        i++;
        j--;
    }
}



int* reverse10()
{
    int* arr = new int[10];

    cout << "Enter 10 integers:" << endl;
    for (int i = 0; i < 10; i++)
        cin >> arr[i];

    for (int i = 0; i < 5; i++) {
        int temp = arr[i];
        arr[i] = arr[9 - i];
        arr[9 - i] = temp;
    }

    return arr;
}