#include "Stack.h"
#include <iostream>

void push(Stack* s, unsigned int element)
{
	Node* newHead = new Node();

	newHead->data = element;
	newHead->next = s->top;

	s->top = newHead;

}


int pop(Stack* s)
{
	if (s == nullptr || s->top == nullptr)
		return -1;

	Node* temp = s->top;
	unsigned int val = temp->data;
	Node* newHead = temp->next;
	s->top = newHead;
	delete temp;
	return val;
}
void initStack(Stack* s)
{
	s->top = nullptr;
}


void cleanStack(Stack* s)
{
	if (s == nullptr || s->top == nullptr)
		return;

	Node* temp;

	while (s->top != nullptr )
	{
		temp = s->top;
		s->top = temp->next;
		delete temp;
	}
}



bool isEmpty(Stack* s)
{
	if (s == nullptr || s->top == nullptr)
		return true;
	return false;
}

bool isFull(Stack* s)
{
	return false;
}