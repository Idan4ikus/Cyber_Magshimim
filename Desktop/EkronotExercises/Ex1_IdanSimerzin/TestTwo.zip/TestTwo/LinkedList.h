#ifndef LINKEDLISTH
#define LINKEDLISTH

typedef struct Node
{
	unsigned int data;
	struct Node* next;
}Node;


void AddToTheList(Node** lst, unsigned int newNode);//Adds to the end if the Node is empty just adds it and stops the func

void DeleteOfTheList(Node** lst);//If the Length of the Node is one it will clear the Node and stop the func else it will delete the last Node





#endif



