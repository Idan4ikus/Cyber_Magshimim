#include <iostream>
#include "Queue.h"

void initQueue(Queue* q, unsigned int size)
{
    q->elements = new unsigned int[size];
    q->head = 0;
    q->tail = 0;
    q->count = 0;
    q->limit = size;
}

void cleanQueue(Queue* q)
{
    q->elements = nullptr;
    q->head = 0;
    q->tail = 0;
    q->count = 0;
    q->limit = 0;
}

void enqueue(Queue* q, unsigned int value)
{
    q->elements[q->tail] = value;
    q->tail += 1;
    q->count += 1;
}

int dequeue(Queue* q)
{
    unsigned int num = q->elements[q->head];
    q->head = (q->head + 1) % q->limit;
    q->count -= 1;
    return num;
}

bool isEmpty(Queue* q)
{
    return q->count == 0;
}

bool isFull(Queue* q)
{
    return q->count == q->limit;
}
