#include <iostream>
#include "LinkedList.h"

void AddToTheList(Node** lst, unsigned int newNode)//Adds to the end if the Node is empty just adds it and stops the func
{
	Node* newHead = new Node();

	newHead->data = newNode;
	newHead->next = nullptr;

	if (*lst == nullptr)
	{

		*lst = newHead;
		return;
	}

	Node* temp = *lst;

	while (temp->next != nullptr)
	{
		temp = temp->next;
	}
	temp->next = (newHead);

}

void DeleteOfTheList(Node** lst)//If the Length of the Node is one it will clear the Node and stop the func else it will delete the last Node
{


	//if ((*lst)->next == nullptr)
	//{
	//	delete* lst;
	//	*lst = nullptr;
	//	return;
	//}

	//Node* temp = *lst;
	//while (temp->next->next != nullptr)
	//{
	//	temp = temp->next;
	//}

	//delete temp->next;
	//temp->next = nullptr;

	if (*lst == nullptr) {
		return;
	}
	if ((*lst)->next == nullptr) {
		delete* lst;
		*lst = nullptr;
		return;
	}
	Node* temp = *lst;
	while (temp->next->next != nullptr) {
		temp = temp->next;
	}
	delete temp->next;
	temp->next = nullptr;
}